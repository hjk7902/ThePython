# -*- coding: utf-8 -*-

print("_mypkg_foo loaded")

