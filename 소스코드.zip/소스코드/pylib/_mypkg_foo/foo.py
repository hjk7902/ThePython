# -*- coding: utf-8 -*-

def foo_hello():
    print('foo hello')
    