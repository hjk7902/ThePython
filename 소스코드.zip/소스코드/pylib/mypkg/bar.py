# -*- coding: utf-8 -*-

def bar_hello():
    print('bar hello')
    
    